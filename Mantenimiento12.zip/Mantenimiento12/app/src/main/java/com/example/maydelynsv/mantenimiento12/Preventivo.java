package com.example.maydelynsv.mantenimiento12;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Preventivo extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_preventivo);


        Button Siguiente2 = (Button) findViewById(R.id.Limpieza);
        Siguiente2.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Preventivo.this, Limpieza.class));
            }
        });

        Button Siguiente3 = (Button) findViewById(R.id.Desfragmentar);
        Siguiente3.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Preventivo.this, Correctivo2.class));

            }
        });


        Button Siguiente4 = (Button) findViewById(R.id.Actualizar);
        Siguiente4.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(Preventivo.this, aplicacion.class));
            }

        });

        Button Siguiente5 = (Button) findViewById(R.id.memoria);
        Siguiente5.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                startActivity(new Intent(Preventivo.this, Liberacion.class));
            }

        });

        Button Siguiente6 = (Button) findViewById(R.id.vaciar);
        Siguiente6.setOnClickListener(new View.OnClickListener() {


            @Override
            public void onClick(View v) {
                startActivity(new Intent(Preventivo.this, Papelaje.class));
            }
        });


    }
}
